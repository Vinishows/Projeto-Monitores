const express = require('express');
const db = require('@supabase/supabase-js');
const bodyParser = require('body-parser');
const { log } = require('console');

const app = express();
const url = process.env['SUPA_URL'];
const api = process.env['SUPA_API'];
const supabase = db.createClient(url, api);
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static('public'));
app.use(express.static('assets'));

const loggedInUsers = {};

const searchAluno = async (req, res) => {
  const { matricula, senha } = req.body;
  const { data, error } = await supabase
    .from('alunos')
    .select('*')
    .eq('matricula', matricula)
    .eq('senha', senha);

  if (error) {
    res.send(error);
    console.log("Erro:", error.message);
    return;
  }

  if (data && data.length > 0) {
    const aluno = data[0];
    const sessionId = req.sessionID;

    loggedInUsers[sessionId] = { nome: aluno.nome, sobrenome: aluno.sobrenome };

    console.log("Login feito com sucesso!");

    if (aluno.monitor) {
      res.redirect('/monitores');
    } else {
      res.redirect('/alunos');
    }
  } else {
    console.log("Falha no login!");
    res.send('<script>alert("Falha no login!"); window.location.href = "/";</script>');
  }
}

const reservaSala = async (req, res) => {
  const { materia, bloco, num_sala, turno, horario } = req.body;
  const sessionId = req.sessionID;

  if (!loggedInUsers[sessionId]) {
    console.log("Usuário não está logado.");
    res.send('<script>alert("Usuário não está logado!"); window.location.href = "/";</script>');
    return;
  }

  const { nome, sobrenome } = loggedInUsers[sessionId];

  const { data: salaExists, error: salaError } = await supabase
    .from('salas')
    .select('*')
    .eq('bloco', bloco)
    .eq('num_sala', num_sala);

  if (salaError) {
    throw salaError;
  }

  if (!salaExists || salaExists.length === 0) {
    console.log('Sala ou bloco não encontrados.');
    return;
  }

  const { data: horarioExists, error: horarioError } = await supabase
    .from('horarios')
    .select('*')
    .eq('turno', turno)
    .eq('horario', horario);

  if (horarioError) {
    throw horarioError;
  }

  if (!horarioExists || horarioExists.length === 0) {
    console.log('Horário ou turno não encontrados.');
    return;
  }

  const { data: existingReservations, error: reservationError } = await supabase
    .from('reservas')
    .select('*')
    .eq('bloco', bloco)
    .eq('num_sala', num_sala)
    .eq('turno', turno)
    .eq('horario', horario);

  if (reservationError) {
    throw reservationError;
  }

  if (existingReservations && existingReservations.length > 0) {
    console.log('Reserva Indisponível. Sala já ocupada neste horário.');
    res.send('<script>alert("Reserva Indisponível! Sala já ocupada neste horário."); window.location.href = "/reserva";</script>');
  } else {
    const { data: newReservation, error: newReservationError } = await supabase
      .from('reservas')
      .insert([{ materia, bloco, num_sala, turno, horario, nome, sobrenome }]);

    if (newReservationError) {
      throw newReservationError;
    }
    console.log('Reserva realizada com sucesso!');
    res.send('<script>alert("Reserva realizada com sucesso!"); window.location.href = "/monitores";</script>');
  }
}

app.get('/monitores', (req, res) => {
  res.sendFile(__dirname + '/monitores.html');
})

app.get('/alunos', (req, res) => {
  res.sendFile(__dirname + '/alunos.html');
})

app.get('/cards', async (req, res) => {
  const { materia } = req.query;

  try {
    const query = supabase
      .from('reservas')
      .select('*');

    if (materia) {
      query.eq('materia', materia);
    }

    const { data: reservas, error } = await query;

    if (error) {
      throw error;
    }

    const cardsHtml = reservas.map((reserva) => {
      return `
        <div class="col-md-4">
          <div class="card" onclick="location.href='/detalhes?materia=${reserva.materia}&bloco=${reserva.bloco}&num_sala=${reserva.num_sala}&turno=${reserva.turno}&horario=${reserva.horario}&nome=${reserva.nome}&sobrenome=${reserva.sobrenome}'">
            <div class="card-body">
              <h2 class="titulo2">${reserva.materia}</h2>
              <p>Bloco ${reserva.bloco} - Sala ${reserva.num_sala}<br> 
                 ${reserva.turno} - ${reserva.horario}<br>
                 Monitor: ${reserva.nome} ${reserva.sobrenome}</p>
            </div>
          </div>
        </div>
      `;
    }).join('');

    res.send(cardsHtml);
  } catch (error) {
    console.error('Erro ao buscar reservas:', error.message);
    res.status(500).send('Erro ao buscar reservas');
  }
});

app.get('/reserva', (req, res) => {
  res.sendFile('reserva.html', { root: __dirname });
});
app.post('/reserva', reservaSala);

app.get('/', (req, res) => {
  res.sendFile('login.html', { root: __dirname });
});
app.post('/', searchAluno);

app.get('/detalhes', (req, res) => {
  res.sendFile('detalhes.html', { root: __dirname });
});

app.get('/disciplina', (req, res) => {
  res.sendFile('disciplina.html', { root: __dirname });
});

app.listen(3000, () => {
  console.log('Executando');
});
